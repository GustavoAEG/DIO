﻿using DesafioPOO.Models;

// TODO: Realizar os testes com as classes Nokia e Iphone