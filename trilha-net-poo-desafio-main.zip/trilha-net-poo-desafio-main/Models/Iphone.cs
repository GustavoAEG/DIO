namespace DesafioPOO.Models
{
    // TODO: Herdar da classe "Smartphone"
    public class Iphone
    {
        // TODO: Sobrescrever o método "InstalarAplicativo"
    }
}