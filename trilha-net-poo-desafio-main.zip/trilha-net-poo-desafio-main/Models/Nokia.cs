namespace DesafioPOO.Models
{
    // TODO: Herdar da classe "Smartphone"
    public class Nokia
    {
        // TODO: Sobrescrever o método "InstalarAplicativo"
    }
}